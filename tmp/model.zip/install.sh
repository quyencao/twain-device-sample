#!/bin/bash

pip3 install -r requirements.txt